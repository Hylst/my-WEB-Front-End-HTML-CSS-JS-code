# effet-papillon
Demo of a french web page about a funny text in french. Done for practice of my HTML / CSS knowledge ( no CSS preprocessor or javascript here )
